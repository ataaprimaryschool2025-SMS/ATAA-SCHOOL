import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Facebook, Twitter, Rss, ArrowRight, CheckCircle2, Sparkles, X, Heart, ShieldAlert } from 'lucide-react';

import Header from './components/Header';
import HeroCarousel from './components/HeroCarousel';
import FeatureBlocks from './components/FeatureBlocks';
import AboutUsTab from './components/AboutUsTab';
import CharitiesTab from './components/CharitiesTab';
import ProgramsTab from './components/ProgramsTab';
import FAQTab from './components/FAQTab';
import ContactsTab from './components/ContactsTab';
import StaffPortalTab from './components/StaffPortalTab';

import { NEWS_ITEMS } from './data';
import { NewsItem } from './types';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [isNewsletterSuccess, setIsNewsletterSuccess] = useState(false);
  
  // Selected news article modal
  const [selectedNews, setSelectedNews] = useState<NewsItem | null>(null);

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;
    setIsNewsletterSuccess(true);
    setTimeout(() => {
      setNewsletterEmail('');
    }, 4000);
  };

  const handleNewsClick = (item: NewsItem) => {
    setSelectedNews(item);
  };

  const handleCloseNewsModal = () => {
    setSelectedNews(null);
  };

  // Render correct tab view with layout animations
  const renderTabView = () => {
    switch (currentTab) {
      case 'about':
        return <AboutUsTab key="about-tab" />;
      case 'charities':
        return <CharitiesTab key="charities-tab" />;
      case 'programs':
        return <ProgramsTab key="programs-tab" />;
      case 'faqs':
        return <FAQTab key="faqs-tab" />;
      case 'contacts':
        return <ContactsTab key="contacts-tab" />;
      case 'staff':
        return <StaffPortalTab key="staff-tab" />;
      case 'home':
      default:
        return (
          <div key="home-tab" className="space-y-6">
            {/* Banner / Hero Carousel exactly as shown in screenshot */}
            <HeroCarousel />

            {/* Elastic Feature Cards Grid exactly as shown in screenshot */}
            <FeatureBlocks onNavigate={(tabId) => setCurrentTab(tabId)} />

            {/* 2-Column Main Content Block */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-2">
              
              {/* LEFT COLUMN: About us Block (7 cols) */}
              <div className="lg:col-span-8 bg-white rounded-2xl p-6 md:p-8 shadow-md border-b-4 border-slate-200">
                <h2 className="font-display font-bold text-3xl text-[#0096d9] mb-4 border-b pb-3 border-sky-100 flex items-center justify-between">
                  <span>About us</span>
                  <Sparkles size={20} className="text-[#eab308] animate-pulse" />
                </h2>
                
                <p className="text-sm md:text-base text-slate-500 leading-relaxed font-sans mb-8">
                  Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea.
                </p>

                {/* Sub items matching image layout */}
                <div className="space-y-6">
                  
                  {/* Sub item 1 */}
                  <div className="flex flex-col sm:flex-row gap-5 items-start p-4 bg-slate-50 rounded-xl hover:bg-slate-100/80 transition-colors border border-slate-100">
                    <img 
                      src="https://images.unsplash.com/photo-1509062522246-3755977927d7?q=80&w=300&auto=format&fit=crop" 
                      alt="Kids in classroom" 
                      className="w-full sm:w-1/3 aspect-[4/3] rounded-lg object-cover shadow-xs border border-slate-200"
                      referrerPolicy="no-referrer"
                    />
                    <div className="flex-1 space-y-2">
                      <h3 className="font-display font-bold text-base md:text-lg text-[#0096d9] leading-tight">
                        Lorem ipsum dolor sit amet conse ctetur ad
                      </h3>
                      <p className="text-xs md:text-sm text-slate-500 leading-relaxed line-clamp-3">
                        Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit.
                      </p>
                      <button 
                        onClick={() => handleNewsClick(NEWS_ITEMS[0])}
                        className="text-xs font-bold text-[#0096d9] hover:underline flex items-center gap-1 cursor-pointer select-none pt-1"
                      >
                        <span>more</span>
                        <ArrowRight size={12} />
                      </button>
                    </div>
                  </div>

                  {/* Sub item 2 */}
                  <div className="flex flex-col sm:flex-row gap-5 items-start p-4 bg-slate-50 rounded-xl hover:bg-slate-100/80 transition-colors border border-slate-100">
                    <img 
                      src="https://images.unsplash.com/photo-1516627145497-ae6968895b74?q=80&w=300&auto=format&fit=crop" 
                      alt="Kids reading books" 
                      className="w-full sm:w-1/3 aspect-[4/3] rounded-lg object-cover shadow-xs border border-slate-200"
                      referrerPolicy="no-referrer"
                    />
                    <div className="flex-1 space-y-2">
                      <h3 className="font-display font-bold text-base md:text-lg text-[#0096d9] leading-tight">
                        Dolor sit amet conse ctetur ad
                      </h3>
                      <p className="text-xs md:text-sm text-slate-500 leading-relaxed line-clamp-3">
                        Sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse.
                      </p>
                      <button 
                        onClick={() => handleNewsClick(NEWS_ITEMS[1])}
                        className="text-xs font-bold text-[#0096d9] hover:underline flex items-center gap-1 cursor-pointer select-none pt-1"
                      >
                        <span>more</span>
                        <ArrowRight size={12} />
                      </button>
                    </div>
                  </div>

                </div>

                {/* More About Us anchor at bottom left */}
                <div className="mt-8 pt-4 border-t border-slate-100">
                  <motion.button
                    id="btn-more-about"
                    onClick={() => setCurrentTab('about')}
                    className="text-[#16a34a] hover:text-[#15803d] font-display font-bold text-sm md:text-base flex items-center gap-1.5 cursor-pointer select-none"
                    whileHover={{ x: 4 }}
                  >
                    <span>more about us</span>
                    <ArrowRight size={16} />
                  </motion.button>
                </div>
              </div>

              {/* RIGHT COLUMN: News & Newsletter Widgets (4 cols) */}
              <div className="lg:col-span-4 space-y-6 flex flex-col justify-between">
                
                {/* Latest News Widget (Light blue background exactly like image) */}
                <div className="bg-[#00aaff] rounded-2xl p-6 shadow-md border-b-4 border-white/20 text-white flex-1 flex flex-col justify-between">
                  <div>
                    <h2 className="font-display font-bold text-2xl tracking-wide text-white mb-4 drop-shadow-sm select-none">
                      Latest news
                    </h2>
                    
                    <div className="space-y-5">
                      {NEWS_ITEMS.slice(0, 2).map((item) => (
                        <div key={item.id} className="space-y-1.5 group">
                          {/* Yellow badge style exactly matching screenshot */}
                          <div className="inline-block bg-[#eab308] text-slate-900 font-display font-bold text-xs px-2.5 py-0.5 rounded-sm shadow-xs select-none">
                            {item.date}
                          </div>
                          <h3 className="font-display font-bold text-sm text-white group-hover:text-amber-200 transition-colors cursor-pointer" onClick={() => handleNewsClick(item)}>
                            {item.title}
                          </h3>
                          <p className="text-xs leading-relaxed text-blue-50 line-clamp-2">
                            {item.excerpt}
                          </p>
                          <button 
                            onClick={() => handleNewsClick(item)}
                            className="text-[11px] font-bold text-amber-200 hover:underline flex items-center gap-0.5 cursor-pointer select-none"
                          >
                            <span>more</span>
                            <ArrowRight size={10} />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="mt-5 pt-4 border-t border-white/20">
                    <button 
                      onClick={() => setCurrentTab('about')}
                      className="text-xs font-display font-bold text-amber-200 hover:underline flex items-center gap-1 cursor-pointer select-none"
                    >
                      <span>see all news</span>
                      <ArrowRight size={12} />
                    </button>
                  </div>
                </div>

                {/* Newsletter Subscriber Widget (Purple-magenta background like image) */}
                <div className="bg-[#a21caf] rounded-2xl p-6 shadow-md border-b-4 border-white/20 text-white relative overflow-hidden">
                  <div className="absolute -right-6 -top-6 w-16 h-16 bg-white/5 rounded-full" />
                  
                  <h2 className="font-display font-bold text-2xl tracking-wide text-white mb-3 select-none">
                    Newsletter
                  </h2>

                  <AnimatePresence mode="wait">
                    {!isNewsletterSuccess ? (
                      <motion.form 
                        key="news-form"
                        onSubmit={handleNewsletterSubmit} 
                        className="space-y-3.5"
                        exit={{ opacity: 0, y: -10 }}
                      >
                        <p className="text-xs text-purple-100 leading-relaxed font-sans">
                          Subscribe to get weekly updates, children activity logs, and photo galleries from our Glasgow center.
                        </p>
                        
                        <input
                          type="email"
                          required
                          placeholder="Your email address"
                          value={newsletterEmail}
                          onChange={(e) => setNewsletterEmail(e.target.value)}
                          className="w-full px-3.5 py-2 rounded-xl text-slate-800 bg-white placeholder-slate-400 focus:outline-hidden focus:ring-3 focus:ring-purple-300 text-xs font-semibold"
                        />

                        <div className="flex justify-start">
                          <motion.button
                            id="btn-subscribe-newsletter"
                            type="submit"
                            className="bg-[#ea580c] hover:bg-[#c2410c] text-white px-5 py-2 rounded-xl text-xs font-display font-bold shadow-xs select-none cursor-pointer"
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                          >
                            subscribe!
                          </motion.button>
                        </div>
                      </motion.form>
                    ) : (
                      <motion.div
                        key="news-success"
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="text-center py-4 space-y-2.5"
                      >
                        <CheckCircle2 className="mx-auto text-amber-300 stroke-[2.5]" size={32} />
                        <h4 className="font-display font-bold text-sm text-white">Subscribed Successfully!</h4>
                        <p className="text-[10px] text-purple-100 leading-relaxed max-w-[200px] mx-auto">
                          Thank you! We've added you to our community bulletin list.
                        </p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

              </div>

            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#0096d9] flex flex-col font-sans selection:bg-[#ea580c] selection:text-white">
      
      {/* Outer framing wrapper to give it a neat web portal feel */}
      <div className="flex-1 w-full max-w-6xl mx-auto px-4 py-4 md:py-6 flex flex-col gap-6">
        
        {/* Playful Header Navigation */}
        <Header currentTab={currentTab} setCurrentTab={setCurrentTab} />

        {/* Dynamic Main Body Content with Framer Motion slide effects */}
        <main className="flex-1">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentTab}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
            >
              {renderTabView()}
            </motion.div>
          </AnimatePresence>
        </main>

        {/* FOOTER SECTION: Exactly matches color scheme and structure in screenshot */}
        <footer className="mt-8 pt-8 border-t-2 border-dashed border-white/20 text-white/90">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6 pb-6">
            
            {/* Footer Navigation Links in yellowish-green exactly like image */}
            <div className="flex flex-wrap gap-x-4 md:gap-x-6 gap-y-2 text-xs font-display font-semibold text-[#a3e635]">
              {['home', 'about', 'charities', 'programs', 'faqs', 'contacts', 'staff'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setCurrentTab(tab)}
                  className="hover:text-white hover:underline transition-colors capitalize cursor-pointer select-none font-sans font-bold"
                >
                  {tab === 'charities' ? 'Our Charities' : tab === 'staff' ? 'Staff Portal' : tab}
                </button>
              ))}
            </div>

            {/* Social Media Circular Buttons */}
            <div className="flex items-center gap-3">
              <motion.a
                href="#facebook"
                aria-label="Facebook Link"
                className="p-2 bg-blue-600 rounded-full text-white flex items-center justify-center hover:bg-blue-700 shadow-sm"
                whileHover={{ scale: 1.15, y: -3 }}
                whileTap={{ scale: 0.9 }}
              >
                <Facebook size={16} />
              </motion.a>
              <motion.a
                href="#twitter"
                aria-label="Twitter Link"
                className="p-2 bg-sky-500 rounded-full text-white flex items-center justify-center hover:bg-sky-600 shadow-sm"
                whileHover={{ scale: 1.15, y: -3 }}
                whileTap={{ scale: 0.9 }}
              >
                <Twitter size={16} />
              </motion.a>
              <motion.a
                href="#rss"
                aria-label="RSS Feed Link"
                className="p-2 bg-[#ea580c] rounded-full text-white flex items-center justify-center hover:bg-[#c2410c] shadow-sm"
                whileHover={{ scale: 1.15, y: -3 }}
                whileTap={{ scale: 0.9 }}
              >
                <Rss size={16} />
              </motion.a>
            </div>
          </div>

          {/* Copyright/Lorem footer text */}
          <div className="text-center md:text-left text-[11px] text-white/60 font-sans border-t border-white/10 pt-4 pb-2 leading-relaxed">
            <p>
              Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
            </p>
            <p className="mt-1">
              &copy; 2026 Charity. All rights reserved. Registered non-profit SC042301. Glasgow, Scotland.
            </p>
          </div>
        </footer>

      </div>

      {/* FULL READ MORE NEWS ARTICLE DIALOG MODAL */}
      <AnimatePresence>
        {selectedNews && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={handleCloseNewsModal}
              className="absolute inset-0 bg-slate-950/60 backdrop-blur-xs"
            />

            <motion.div
              initial={{ scale: 0.92, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.92, opacity: 0 }}
              className="relative bg-white w-full max-w-lg rounded-2xl shadow-xl overflow-hidden z-10 border border-slate-100 flex flex-col font-sans"
            >
              <div className="bg-[#00aaff] text-white p-5 flex items-center justify-between">
                <span className="bg-[#eab308] text-slate-900 font-display font-bold text-xs px-2.5 py-0.5 rounded-sm">
                  {selectedNews.date}
                </span>
                <button 
                  onClick={handleCloseNewsModal}
                  className="text-white hover:text-red-100 p-1 rounded-full hover:bg-white/10 transition-colors cursor-pointer select-none"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="p-6 space-y-4">
                <h3 className="font-display font-bold text-xl md:text-2xl text-slate-800 leading-tight">
                  {selectedNews.title}
                </h3>
                <p className="text-xs md:text-sm text-slate-600 leading-relaxed">
                  {selectedNews.content}
                </p>
              </div>

              <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end">
                <button
                  onClick={handleCloseNewsModal}
                  className="bg-slate-800 hover:bg-slate-900 text-white px-5 py-1.5 rounded-xl text-xs font-display font-semibold cursor-pointer select-none"
                >
                  Close Article
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
