export interface CarouselSlide {
  id: number;
  image: string;
  title: string;
  subtitle: string;
  dotsColor: string[];
}

export interface FeatureBox {
  id: string;
  title: string;
  description: string;
  bgColor: string;
  btnColor: string;
  icon: string;
}

export interface NewsItem {
  id: number;
  date: string;
  title: string;
  excerpt: string;
  content: string;
}

export interface CharityProject {
  id: string;
  title: string;
  category: string;
  description: string;
  image: string;
  goal: number;
  raised: number;
  donorsCount: number;
}

export interface ProgramItem {
  id: string;
  title: string;
  ageGroup: string;
  duration: string;
  description: string;
  image: string;
  schedule: string;
}

export interface FAQItem {
  id: number;
  category: 'donations' | 'volunteering' | 'programs' | 'general';
  question: string;
  answer: string;
}

export interface UserAccount {
  id: string;
  username: string;
  fullName: string;
  email: string;
  role: 'Administrator' | 'Coordinator' | 'Volunteer';
  status: 'Active' | 'Inactive';
  password?: string;
}

