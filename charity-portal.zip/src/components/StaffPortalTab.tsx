import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Lock, Mail, User, LogIn, LogOut, Users, UserPlus, 
  Edit2, Trash2, CheckCircle2, AlertCircle, Eye, EyeOff, 
  Search, Filter, ShieldAlert, Check, X, Shield, RefreshCw 
} from 'lucide-react';
import { UserAccount } from '../types';
import { INITIAL_USERS } from '../data';

export default function StaffPortalTab() {
  // Persistence state
  const [users, setUsers] = useState<UserAccount[]>([]);
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);

  // Login form state
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Management controls
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRoleFilter, setSelectedRoleFilter] = useState<string>('all');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('all');

  // Add/Edit Modal and Form state
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserAccount | null>(null);
  const [formData, setFormData] = useState({
    username: '',
    fullName: '',
    email: '',
    role: 'Volunteer' as 'Administrator' | 'Coordinator' | 'Volunteer',
    status: 'Active' as 'Active' | 'Inactive',
    password: ''
  });
  const [formError, setFormError] = useState('');
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Initialize users from localStorage
  useEffect(() => {
    const cachedUsers = localStorage.getItem('charity_portal_users');
    if (cachedUsers) {
      try {
        setUsers(JSON.parse(cachedUsers));
      } catch (e) {
        setUsers(INITIAL_USERS);
      }
    } else {
      setUsers(INITIAL_USERS);
      localStorage.setItem('charity_portal_users', JSON.stringify(INITIAL_USERS));
    }

    // Check active session
    const cachedSession = localStorage.getItem('charity_portal_active_session');
    if (cachedSession) {
      try {
        setCurrentUser(JSON.parse(cachedSession));
      } catch (e) {
        // ignore
      }
    }
  }, []);

  // Save users helper
  const saveUsersToStorage = (updatedUsers: UserAccount[]) => {
    setUsers(updatedUsers);
    localStorage.setItem('charity_portal_users', JSON.stringify(updatedUsers));
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setIsLoggingIn(true);

    setTimeout(() => {
      // Find matching user (checking standard list)
      const matched = users.find(
        u => u.username.toLowerCase() === loginUsername.toLowerCase() && 
             (u.password === loginPassword || (!u.password && loginPassword === 'admin'))
      );

      if (matched) {
        if (matched.status === 'Inactive') {
          setLoginError('Your staff account is currently marked as Inactive. Please consult an Administrator.');
          setIsLoggingIn(false);
          return;
        }
        setCurrentUser(matched);
        localStorage.setItem('charity_portal_active_session', JSON.stringify(matched));
        // Reset form
        setLoginUsername('');
        setLoginPassword('');
        setLoginError('');
      } else {
        setLoginError('Invalid credentials. (Hint: use admin/admin or sarah/sarah)');
      }
      setIsLoggingIn(false);
    }, 1000);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('charity_portal_active_session');
    showNotification('success', 'Logged out successfully.');
  };

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 4000);
  };

  // Open form for adding a user
  const handleOpenAddForm = () => {
    setEditingUser(null);
    setFormData({
      username: '',
      fullName: '',
      email: '',
      role: 'Volunteer',
      status: 'Active',
      password: ''
    });
    setFormError('');
    setIsFormOpen(true);
  };

  // Open form for editing a user
  const handleOpenEditForm = (user: UserAccount) => {
    setEditingUser(user);
    setFormData({
      username: user.username,
      fullName: user.fullName,
      email: user.email,
      role: user.role,
      status: user.status,
      password: user.password || 'password123'
    });
    setFormError('');
    setIsFormOpen(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    // Basic Validations
    if (!formData.username.trim() || !formData.fullName.trim() || !formData.email.trim()) {
      setFormError('Please fill out all required fields.');
      return;
    }

    if (formData.username.includes(' ')) {
      setFormError('Username cannot contain spaces.');
      return;
    }

    // Check duplicate username (except when editing the same user)
    const isDuplicate = users.some(u => 
      u.username.toLowerCase() === formData.username.toLowerCase() && 
      (!editingUser || u.id !== editingUser.id)
    );

    if (isDuplicate) {
      setFormError('This username is already taken. Please choose another.');
      return;
    }

    if (editingUser) {
      // Editing
      const updated = users.map(u => {
        if (u.id === editingUser.id) {
          return {
            ...u,
            username: formData.username.trim(),
            fullName: formData.fullName.trim(),
            email: formData.email.trim(),
            role: formData.role,
            status: formData.status,
            password: formData.password
          };
        }
        return u;
      });
      saveUsersToStorage(updated);
      
      // If we edited ourselves, update active session
      if (currentUser && currentUser.id === editingUser.id) {
        const selfUpdated = updated.find(u => u.id === currentUser.id)!;
        setCurrentUser(selfUpdated);
        localStorage.setItem('charity_portal_active_session', JSON.stringify(selfUpdated));
      }

      showNotification('success', `Account for "${formData.fullName}" updated successfully.`);
    } else {
      // Adding new
      const newUser: UserAccount = {
        id: `user-${Date.now()}`,
        username: formData.username.trim().toLowerCase(),
        fullName: formData.fullName.trim(),
        email: formData.email.trim(),
        role: formData.role,
        status: formData.status,
        password: formData.password || 'admin123'
      };
      
      const updated = [...users, newUser];
      saveUsersToStorage(updated);
      showNotification('success', `Account for "${formData.fullName}" has been created.`);
    }

    setIsFormOpen(false);
  };

  const handleDeleteUser = (id: string, name: string) => {
    if (currentUser && currentUser.id === id) {
      showNotification('error', 'You cannot delete your own logged-in account.');
      return;
    }

    if (confirm(`Are you sure you want to permanently remove ${name}'s access account?`)) {
      const filtered = users.filter(u => u.id !== id);
      saveUsersToStorage(filtered);
      showNotification('success', `Removed account access for ${name}.`);
    }
  };

  // Reset demo users
  const handleResetDemo = () => {
    if (confirm('Are you sure you want to restore the default demo accounts? All custom additions/edits will be cleared.')) {
      setUsers(INITIAL_USERS);
      localStorage.setItem('charity_portal_users', JSON.stringify(INITIAL_USERS));
      localStorage.removeItem('charity_portal_active_session');
      setCurrentUser(null);
      showNotification('success', 'Demo staff directory has been restored to defaults.');
    }
  };

  // Filter accounts
  const filteredUsers = users.filter(u => {
    const matchesSearch = 
      u.fullName.toLowerCase().includes(searchQuery.toLowerCase()) || 
      u.username.toLowerCase().includes(searchQuery.toLowerCase()) || 
      u.email.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesRole = selectedRoleFilter === 'all' || u.role === selectedRoleFilter;
    const matchesStatus = selectedStatusFilter === 'all' || u.status === selectedStatusFilter;

    return matchesSearch && matchesRole && matchesStatus;
  });

  return (
    <div className="space-y-8">
      {/* Toast Notification */}
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: -50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.9 }}
            className={`
              fixed top-4 right-4 z-50 flex items-center gap-2.5 px-4 py-3.5 rounded-xl shadow-lg border text-sm max-w-sm
              ${notification.type === 'success' 
                ? 'bg-emerald-50 text-emerald-800 border-emerald-100' 
                : 'bg-rose-50 text-rose-800 border-rose-100'}
            `}
          >
            {notification.type === 'success' ? (
              <CheckCircle2 className="text-emerald-500 shrink-0" size={18} />
            ) : (
              <AlertCircle className="text-rose-500 shrink-0" size={18} />
            )}
            <span className="font-semibold">{notification.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Intro Header */}
      <div className="bg-white rounded-2xl p-6 shadow-md border-b-4 border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-display font-bold text-3xl text-purple-700 flex items-center gap-2.5">
              <Users size={28} />
              <span>Staff & Volunteer Portal</span>
            </h2>
            <p className="text-xs md:text-sm text-slate-400 font-sans mt-1">
              Protected administrative tools for early-childhood educators, community sponsors, and school volunteers.
            </p>
          </div>
          
          {currentUser && (
            <motion.button
              onClick={handleLogout}
              className="bg-rose-600 hover:bg-rose-700 text-white px-4.5 py-2 rounded-xl text-xs font-display font-bold flex items-center gap-1.5 shadow-xs cursor-pointer select-none self-start sm:self-center"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <LogOut size={14} />
              <span>Log Out Portal</span>
            </motion.button>
          )}
        </div>
      </div>

      {/* RENDER LOGIN IF NOT LOGGED IN */}
      <AnimatePresence mode="wait">
        {!currentUser ? (
          <motion.div
            key="login-view"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="max-w-md mx-auto"
          >
            <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
              {/* Login Banner Header */}
              <div className="bg-linear-to-r from-purple-700 to-indigo-600 text-white p-6 text-center space-y-1">
                <div className="inline-flex items-center justify-center p-3 bg-white/10 rounded-full mb-2">
                  <Lock size={24} className="text-purple-100" />
                </div>
                <h3 className="font-display font-bold text-2xl">Demo Portal Sign In</h3>
                <p className="text-xs text-purple-200">Authentication Required to Manage Directory</p>
              </div>

              {/* Form container */}
              <form onSubmit={handleLoginSubmit} className="p-6 space-y-5 font-sans">
                {loginError && (
                  <motion.div
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-3 bg-rose-50 border border-rose-100 text-rose-700 text-xs rounded-xl flex items-start gap-2"
                  >
                    <ShieldAlert size={16} className="shrink-0 mt-0.5 text-rose-500" />
                    <span>{loginError}</span>
                  </motion.div>
                )}

                {/* Username Input */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                    Username
                  </label>
                  <div className="relative">
                    <User size={16} className="absolute left-3 top-3 text-slate-400" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. admin or sarah"
                      value={loginUsername}
                      onChange={(e) => setLoginUsername(e.target.value)}
                      className="pl-9.5 pr-4 py-2.5 w-full bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-purple-600 focus:bg-white transition-all text-slate-700"
                    />
                  </div>
                </div>

                {/* Password Input */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                    Password
                  </label>
                  <div className="relative">
                    <Lock size={16} className="absolute left-3 top-3 text-slate-400" />
                    <input
                      type={showPassword ? "text" : "password"}
                      required
                      placeholder="e.g. admin or sarah"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      className="pl-9.5 pr-10 py-2.5 w-full bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-purple-600 focus:bg-white transition-all text-slate-700"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-3 text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                {/* Submit Row */}
                <motion.button
                  id="btn-login-portal"
                  type="submit"
                  disabled={isLoggingIn}
                  className="w-full bg-purple-700 hover:bg-purple-800 text-white py-3 rounded-xl font-display font-bold text-sm tracking-wide shadow-md flex items-center justify-center gap-2 cursor-pointer select-none disabled:opacity-75"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {isLoggingIn ? (
                    <>
                      <div className="animate-spin rounded-full h-4.5 w-4.5 border-2 border-white border-t-transparent" />
                      <span>Verifying Authority...</span>
                    </>
                  ) : (
                    <>
                      <LogIn size={15} />
                      <span>Authenticate Access</span>
                    </>
                  )}
                </motion.button>
              </form>

              {/* Hint Callout Card */}
              <div className="bg-slate-50 p-4 border-t border-slate-100 text-xs text-slate-500 font-sans space-y-2">
                <span className="font-bold text-slate-700 uppercase tracking-wide flex items-center gap-1.5">
                  <Shield size={13} className="text-indigo-500" />
                  <span>Authorized Demo Credentials:</span>
                </span>
                <ul className="list-disc pl-4 space-y-1 text-slate-600">
                  <li><strong>Administrator:</strong> Username <code className="bg-white px-1 py-0.5 rounded border">admin</code> &amp; Password <code className="bg-white px-1 py-0.5 rounded border">admin</code></li>
                  <li><strong>Coordinator:</strong> Username <code className="bg-white px-1 py-0.5 rounded border">sarah</code> &amp; Password <code className="bg-white px-1 py-0.5 rounded border">sarah</code></li>
                  <li><strong>Volunteer:</strong> Username <code className="bg-white px-1 py-0.5 rounded border">volunteer_jane</code> &amp; Password <code className="bg-white px-1 py-0.5 rounded border">jane</code></li>
                </ul>
              </div>
            </div>
          </motion.div>
        ) : (
          /* LOGGED IN PORTAL VIEW */
          <motion.div
            key="dashboard-view"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-6"
          >
            {/* Status Strip */}
            <div className="bg-purple-50 rounded-2xl p-4 border border-purple-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-100 rounded-full text-purple-700">
                  <Shield size={20} />
                </div>
                <div>
                  <div className="text-xs text-purple-500 font-bold uppercase tracking-wider">Authentication Verified</div>
                  <div className="text-sm font-semibold text-slate-800">
                    Logged in as: <strong className="text-purple-700 font-bold">{currentUser.fullName}</strong> 
                    <span className="ml-1.5 bg-purple-100 text-purple-800 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider">
                      {currentUser.role}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end">
                <button
                  onClick={handleResetDemo}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1 cursor-pointer select-none"
                  title="Reset Staff List to Initial Defaults"
                >
                  <RefreshCw size={13} />
                  <span>Restore Defaults</span>
                </button>
                <motion.button
                  id="btn-add-staff"
                  onClick={handleOpenAddForm}
                  className="bg-purple-700 hover:bg-purple-800 text-white px-4 py-2 rounded-xl text-xs font-display font-bold flex items-center gap-1.5 shadow-sm cursor-pointer select-none"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <UserPlus size={14} />
                  <span>Add New Staff</span>
                </motion.button>
              </div>
            </div>

            {/* Filters and Search toolbar */}
            <div className="bg-white rounded-2xl p-4.5 shadow-xs border border-slate-100 grid grid-cols-1 md:grid-cols-12 gap-3">
              {/* Search */}
              <div className="relative md:col-span-6">
                <Search size={16} className="absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search staff by name, username or email..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 pr-4 py-2 w-full bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-hidden focus:ring-2 focus:ring-purple-600 focus:bg-white transition-all text-slate-700 font-medium"
                />
              </div>

              {/* Role filter */}
              <div className="relative md:col-span-3">
                <select
                  value={selectedRoleFilter}
                  onChange={(e) => setSelectedRoleFilter(e.target.value)}
                  className="px-3 py-2 w-full bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-hidden focus:ring-2 focus:ring-purple-600 focus:bg-white transition-all text-slate-700 font-medium cursor-pointer"
                >
                  <option value="all">All Roles</option>
                  <option value="Administrator">Administrators</option>
                  <option value="Coordinator">Coordinators</option>
                  <option value="Volunteer">Volunteers</option>
                </select>
              </div>

              {/* Status filter */}
              <div className="relative md:col-span-3">
                <select
                  value={selectedStatusFilter}
                  onChange={(e) => setSelectedStatusFilter(e.target.value)}
                  className="px-3 py-2 w-full bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-hidden focus:ring-2 focus:ring-purple-600 focus:bg-white transition-all text-slate-700 font-medium cursor-pointer"
                >
                  <option value="all">All Statuses</option>
                  <option value="Active">Active Accounts</option>
                  <option value="Inactive">Inactive Accounts</option>
                </select>
              </div>
            </div>

            {/* STAFF DIRECTORY GRID / CARDS */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <AnimatePresence mode="popLayout">
                {filteredUsers.length > 0 ? (
                  filteredUsers.map((user) => {
                    const isSelf = currentUser && currentUser.id === user.id;
                    const isActive = user.status === 'Active';

                    return (
                      <motion.div
                        key={user.id}
                        id={`user-directory-card-${user.id}`}
                        layout
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        transition={{ duration: 0.2 }}
                        className={`
                          bg-white p-5 rounded-2xl border shadow-xs relative flex flex-col justify-between group
                          ${isSelf ? 'ring-2 ring-purple-600 border-purple-100' : 'border-slate-100'}
                          ${!isActive ? 'opacity-70 bg-slate-50/50' : ''}
                        `}
                      >
                        {/* Status Dots */}
                        <div className="absolute top-4 right-4 flex items-center gap-1.5 select-none">
                          <span className={`w-2 h-2 rounded-full ${isActive ? 'bg-emerald-500' : 'bg-slate-400'}`} />
                          <span className="text-[10px] font-bold font-mono uppercase text-slate-400">
                            {user.status}
                          </span>
                        </div>

                        {/* Top Block details */}
                        <div className="space-y-3 font-sans">
                          {/* Role Badge */}
                          <span className={`
                            inline-block text-[9px] font-bold font-display uppercase tracking-wider px-2 py-0.5 rounded-md
                            ${user.role === 'Administrator' ? 'bg-rose-50 text-rose-700 border border-rose-100' : ''}
                            ${user.role === 'Coordinator' ? 'bg-indigo-50 text-indigo-700 border border-indigo-100' : ''}
                            ${user.role === 'Volunteer' ? 'bg-amber-50 text-amber-700 border border-amber-100' : ''}
                          `}>
                            {user.role} {isSelf && '(You)'}
                          </span>

                          <div>
                            <h4 className="font-display font-bold text-base text-slate-800 group-hover:text-purple-700 transition-colors">
                              {user.fullName}
                            </h4>
                            <p className="text-xs text-slate-400 font-mono">@{user.username}</p>
                          </div>

                          <div className="space-y-1 text-xs text-slate-500">
                            <div className="flex items-center gap-1.5">
                              <Mail size={13} className="text-slate-400" />
                              <span className="truncate">{user.email}</span>
                            </div>
                            <div className="flex items-center gap-1.5 font-mono text-[10px] text-slate-400">
                              <Lock size={12} className="text-slate-300" />
                              <span>Password: <strong className="text-slate-600 font-bold">{user.password || 'admin'}</strong></span>
                            </div>
                          </div>
                        </div>

                        {/* Actions block at bottom */}
                        <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
                          <span className="text-[10px] text-slate-300 font-mono uppercase">ID: {user.id.substring(0, 8)}</span>
                          
                          <div className="flex items-center gap-2">
                            {/* Edit action */}
                            <button
                              id={`edit-user-${user.username}`}
                              onClick={() => handleOpenEditForm(user)}
                              className="p-1.5 bg-slate-50 hover:bg-purple-50 hover:text-purple-700 text-slate-500 rounded-lg transition-colors cursor-pointer"
                              title={`Edit account for ${user.fullName}`}
                            >
                              <Edit2 size={13} />
                            </button>

                            {/* Delete action */}
                            <button
                              id={`delete-user-${user.username}`}
                              onClick={() => handleDeleteUser(user.id, user.fullName)}
                              disabled={isSelf}
                              className={`
                                p-1.5 rounded-lg transition-colors cursor-pointer
                                ${isSelf 
                                  ? 'bg-slate-50 text-slate-300 cursor-not-allowed opacity-50' 
                                  : 'bg-slate-50 hover:bg-rose-50 hover:text-rose-600 text-slate-500'}
                              `}
                              title={isSelf ? "You cannot delete yourself" : `Delete ${user.fullName}`}
                            >
                              <Trash2 size={13} />
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })
                ) : (
                  <motion.div
                    key="no-results"
                    className="col-span-full py-12 text-center bg-white rounded-2xl border border-dashed border-slate-200 font-sans"
                  >
                    <Users size={32} className="mx-auto text-slate-300 mb-2" />
                    <p className="text-slate-500 font-medium text-sm">No staff accounts match your current filter parameters.</p>
                    <button
                      onClick={() => {
                        setSearchQuery('');
                        setSelectedRoleFilter('all');
                        setSelectedStatusFilter('all');
                      }}
                      className="mt-3 text-purple-700 text-xs font-bold hover:underline"
                    >
                      Clear All Search Filters
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* RE-USABLE DIALOG MODAL FOR ADD/EDIT FORM */}
      <AnimatePresence>
        {isFormOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsFormOpen(false)}
              className="absolute inset-0 bg-slate-950/60 backdrop-blur-xs"
            />

            {/* Modal Body */}
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              transition={{ type: "spring", duration: 0.4 }}
              className="relative bg-white w-full max-w-md rounded-2xl shadow-xl overflow-hidden z-10 border border-slate-100 flex flex-col font-sans"
            >
              {/* Header */}
              <div className="bg-purple-700 text-white p-5 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <UserPlus size={20} />
                  <h3 className="font-display font-bold text-lg md:text-xl">
                    {editingUser ? 'Edit Staff Account' : 'Add Staff Member'}
                  </h3>
                </div>
                <button 
                  onClick={() => setIsFormOpen(false)}
                  className="text-white/80 hover:text-white p-1 rounded-full hover:bg-white/10 transition-colors cursor-pointer"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Form Body */}
              <form onSubmit={handleFormSubmit} className="p-6 space-y-4">
                {formError && (
                  <div className="p-2.5 bg-rose-50 border border-rose-100 text-rose-700 text-xs rounded-xl flex items-center gap-1.5">
                    <AlertCircle size={15} className="text-rose-500 shrink-0" />
                    <span>{formError}</span>
                  </div>
                )}

                {/* Full Name */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                    Full Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Leo Jenkins"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    className="px-4 py-2 w-full bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-purple-600 focus:bg-white transition-all text-slate-700 font-medium"
                  />
                </div>

                {/* Username */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                    Username <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. leojennings (no spaces)"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                    className="px-4 py-2 w-full bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-purple-600 focus:bg-white transition-all text-slate-700 font-medium font-mono"
                  />
                </div>

                {/* Email address */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                    Email Address <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="e.g. leo@charitynet.org"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="px-4 py-2 w-full bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-purple-600 focus:bg-white transition-all text-slate-700 font-medium"
                  />
                </div>

                {/* Password input */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                    Login Password <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Set simple login password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className="px-4 py-2 w-full bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-purple-600 focus:bg-white transition-all text-slate-700 font-mono font-medium"
                  />
                </div>

                {/* Dual Column for Role and Status */}
                <div className="grid grid-cols-2 gap-3.5 pt-1">
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                      Assigned Role
                    </label>
                    <select
                      value={formData.role}
                      onChange={(e) => setFormData({ ...formData, role: e.target.value as any })}
                      className="px-3 py-2 w-full bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-purple-600 focus:bg-white transition-all text-slate-700 font-medium cursor-pointer"
                    >
                      <option value="Administrator">Administrator</option>
                      <option value="Coordinator">Coordinator</option>
                      <option value="Volunteer">Volunteer</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                      Account Status
                    </label>
                    <select
                      value={formData.status}
                      onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                      className="px-3 py-2 w-full bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-purple-600 focus:bg-white transition-all text-slate-700 font-medium cursor-pointer"
                    >
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </div>
                </div>

                {/* Submit row */}
                <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2.5">
                  <button
                    type="button"
                    onClick={() => setIsFormOpen(false)}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    id="btn-save-staff-profile"
                    type="submit"
                    className="bg-purple-700 hover:bg-purple-800 text-white px-5 py-2 rounded-xl text-xs font-display font-bold shadow-xs cursor-pointer flex items-center gap-1.5"
                  >
                    <Check size={14} />
                    <span>{editingUser ? 'Save Profile' : 'Create Profile'}</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
