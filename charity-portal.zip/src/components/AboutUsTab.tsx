import { motion } from 'motion/react';
import { Award, Shield, Users, Clock, Flame } from 'lucide-react';

export default function AboutUsTab() {
  const values = [
    { icon: <Shield size={24} className="text-emerald-500" />, title: "Safety & Integrity", desc: "We prioritize complete emotional and physical child safety with full background verification." },
    { icon: <Users size={24} className="text-blue-500" />, title: "Inclusive Care", desc: "Providing accessible education and nutrition support to families regardless of background." },
    { icon: <Award size={24} className="text-amber-500" />, title: "Excellence in Tutoring", desc: "Employing expert, passionate early-childhood educators who design custom reading loops." }
  ];

  const milestones = [
    { year: "2010", title: "Inception in Glasgow", desc: "Founded with a single classroom and a handful of local preschool volunteers." },
    { year: "2014", title: "Warm Meals Expansion", desc: "Launched our primary warm meals program to ensure children are fueled to study." },
    { year: "2019", title: "Creative Arts Center", desc: "Built a fully-equipped sensory, craft, and music center in East Glasgow." },
    { year: "2026", title: "Nationwide Accreditation", desc: "Recognized as a leading standard for municipal preschool educational charity." }
  ];

  const team = [
    { name: "Sarah Jenkins", role: "Executive Director", image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=300&auto=format&fit=crop", bio: "Over 15 years leading non-profit municipal early-childhood networks." },
    { name: "David Miller", role: "Head of Educational Programs", image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=300&auto=format&fit=crop", bio: "Former elementary principal passionate about phonics and creative arts." },
    { name: "Michael Chang", role: "Nutritionist & Chef Coordinator", image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=300&auto=format&fit=crop", bio: "Dedicated to designing organic, balanced meals tailored for high children engagement." }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.3 }}
      className="space-y-12"
    >
      {/* Introduction Hero Card */}
      <div className="bg-white rounded-2xl p-6 md:p-8 shadow-md border-b-4 border-slate-200">
        <h2 className="font-display font-bold text-3xl md:text-4xl text-[#0096d9] mb-4">
          Empowering the Next Generation
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="space-y-4 font-sans text-slate-600 leading-relaxed text-sm md:text-base">
            <p>
              Founded in Glasgow, our charity is dedicated to securing a bright, secure, and highly enriching environment for kids during their most critical early learning years. We believe that safe shelter, creative expression, and hot balanced meals should be accessible to every single child.
            </p>
            <p className="font-medium text-slate-800">
              Through the collaborative efforts of local volunteers, generous corporate sponsors, and dedicated educators, we've touched the lives of over 10,000 children in our decade-long journey.
            </p>
          </div>
          <div className="rounded-xl overflow-hidden border-4 border-slate-100 shadow-sm">
            <img 
              src="https://images.unsplash.com/photo-1516627145497-ae6968895b74?q=80&w=600&auto=format&fit=crop" 
              alt="Kids learning" 
              className="w-full object-cover aspect-video"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </div>

      {/* Core Values Section */}
      <div className="space-y-6">
        <h3 className="font-display font-bold text-2xl text-slate-800 text-center">
          Our Foundation Pillars
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {values.map((v, idx) => (
            <motion.div
              key={v.title}
              className="bg-white rounded-xl p-6 shadow-sm border-t-4 border-[#0096d9] flex flex-col items-center text-center hover:shadow-md transition-shadow"
              whileHover={{ y: -5 }}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.1 }}
            >
              <div className="p-3 bg-slate-50 rounded-full mb-4">
                {v.icon}
              </div>
              <h4 className="font-display font-bold text-lg text-slate-800 mb-2">{v.title}</h4>
              <p className="text-xs md:text-sm text-slate-500 leading-relaxed">{v.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Interactive Timeline Section */}
      <div className="bg-slate-50 rounded-2xl p-6 md:p-8 border border-slate-200">
        <div className="flex items-center gap-2 mb-6">
          <Clock className="text-[#ea580c]" />
          <h3 className="font-display font-bold text-2xl text-slate-800">
            Our Historic Milestones
          </h3>
        </div>
        <div className="relative border-l-2 border-slate-200 ml-4 md:ml-6 pl-6 space-y-8">
          {milestones.map((m, idx) => (
            <motion.div 
              key={m.year}
              className="relative"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.15 }}
            >
              {/* Bullet */}
              <div className="absolute -left-[35px] top-1.5 w-4.5 h-4.5 rounded-full bg-[#ea580c] border-4 border-white shadow-sm" />
              
              <div className="bg-white rounded-xl p-4.5 shadow-xs border border-slate-100 max-w-2xl">
                <span className="font-display font-bold text-lg text-[#ea580c] bg-orange-50 px-2.5 py-0.5 rounded-lg">
                  {m.year}
                </span>
                <h4 className="font-display font-bold text-base text-slate-800 mt-2">{m.title}</h4>
                <p className="text-xs md:text-sm text-slate-500 mt-1 leading-relaxed">{m.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Leadership Team Section */}
      <div className="space-y-6">
        <h3 className="font-display font-bold text-2xl text-slate-800 text-center">
          Meet Our Devoted Leaders
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {team.map((t, idx) => (
            <motion.div
              key={t.name}
              className="bg-white rounded-xl overflow-hidden shadow-sm border border-slate-100 flex flex-col"
              whileHover={{ scale: 1.03 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
            >
              <div className="h-64 overflow-hidden relative bg-slate-100">
                <img 
                  src={t.image} 
                  alt={t.name} 
                  className="w-full h-full object-cover object-top"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-xs px-2.5 py-0.5 rounded-full text-[10px] font-bold text-[#2563eb] tracking-wider uppercase">
                  {t.role}
                </div>
              </div>
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h4 className="font-display font-bold text-lg text-slate-800">{t.name}</h4>
                  <p className="text-xs text-slate-400 font-medium mb-3">{t.role}</p>
                  <p className="text-xs md:text-sm text-slate-500 leading-relaxed italic">
                    "{t.bio}"
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
