import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CHARITY_PROJECTS } from '../data';
import { CharityProject } from '../types';
import { CreditCard, DollarSign, Heart, Mail, User, CheckCircle2, ShieldCheck, X } from 'lucide-react';

export default function CharitiesTab() {
  const [projects, setProjects] = useState<CharityProject[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  
  // Donation flow state
  const [selectedProject, setSelectedProject] = useState<CharityProject | null>(null);
  const [donorName, setDonorName] = useState('');
  const [donorEmail, setDonorEmail] = useState('');
  const [donationAmount, setDonationAmount] = useState<string>('25');
  const [customAmount, setCustomAmount] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvc, setCardCvc] = useState('');
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // Initialize from static data and local storage to make it persistent
  useEffect(() => {
    const cached = localStorage.getItem('charity_projects_raised');
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        const merged = CHARITY_PROJECTS.map(proj => ({
          ...proj,
          raised: parsed[proj.id] || proj.raised,
          donorsCount: (parsed[proj.id + '_donors'] || proj.donorsCount)
        }));
        setProjects(merged);
      } catch (e) {
        setProjects(CHARITY_PROJECTS);
      }
    } else {
      setProjects(CHARITY_PROJECTS);
    }
  }, []);

  const categories = ['all', 'Education', 'Healthcare', 'Nutrition', 'Environment'];

  const filteredProjects = activeCategory === 'all' 
    ? projects 
    : projects.filter(p => p.category.toLowerCase() === activeCategory.toLowerCase());

  const handleOpenDonateModal = (project: CharityProject) => {
    setSelectedProject(project);
    setIsSuccess(false);
    setIsSubmitting(false);
    // Reset inputs
    setDonorName('');
    setDonorEmail('');
    setDonationAmount('25');
    setCustomAmount('');
    setCardNumber('');
    setCardExpiry('');
    setCardCvc('');
  };

  const handleCloseDonateModal = () => {
    setSelectedProject(null);
  };

  const handleAmountSelect = (amount: string) => {
    setDonationAmount(amount);
    setCustomAmount('');
  };

  const handleCustomAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCustomAmount(e.target.value);
    setDonationAmount('custom');
  };

  const handleSubmitDonation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject) return;

    // Determine absolute amount
    const finalAmount = donationAmount === 'custom' 
      ? parseFloat(customAmount) || 0 
      : parseFloat(donationAmount);

    if (finalAmount <= 0) {
      alert('Please enter a valid donation amount.');
      return;
    }

    setIsSubmitting(true);

    // Simulate backend payment verification
    setTimeout(() => {
      // Update local state and localStorage
      const updatedProjects = projects.map(proj => {
        if (proj.id === selectedProject.id) {
          const newRaised = proj.raised + finalAmount;
          const newDonors = proj.donorsCount + 1;
          return {
            ...proj,
            raised: newRaised,
            donorsCount: newDonors
          };
        }
        return proj;
      });

      setProjects(updatedProjects);

      // Save to localStorage
      const cachedData: Record<string, number> = {};
      updatedProjects.forEach(p => {
        cachedData[p.id] = p.raised;
        cachedData[p.id + '_donors'] = p.donorsCount;
      });
      localStorage.setItem('charity_projects_raised', JSON.stringify(cachedData));

      setIsSubmitting(false);
      setIsSuccess(true);
    }, 1500);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.3 }}
      className="space-y-8"
    >
      {/* Introduction */}
      <div className="bg-white rounded-2xl p-6 shadow-md border-b-4 border-slate-200">
        <h2 className="font-display font-bold text-3xl text-[#ea580c] mb-3">
          Our Special Charitable Funds
        </h2>
        <p className="text-sm md:text-base text-slate-500 max-w-2xl leading-relaxed">
          Select one of our focused program pools. Your donations directly support educational toolkits, preschool immunizations, and fresh meals in our center. Filter and support today!
        </p>

        {/* Categories Pills */}
        <div className="flex flex-wrap gap-2 mt-6">
          {categories.map((cat) => (
            <button
              key={cat}
              id={`filter-${cat.toLowerCase()}`}
              onClick={() => setActiveCategory(cat)}
              className={`
                px-4 py-1.5 rounded-lg text-sm font-display font-medium transition-all cursor-pointer select-none capitalize
                ${(activeCategory === cat) 
                  ? 'bg-[#ea580c] text-white shadow-sm' 
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}
              `}
            >
              {cat === 'all' ? 'show all' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Projects */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <AnimatePresence mode="popLayout">
          {filteredProjects.map((p) => {
            const pct = Math.min(Math.round((p.raised / p.goal) * 100), 100);
            
            return (
              <motion.div
                key={p.id}
                id={`project-card-${p.id}`}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.25 }}
                className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-lg transition-shadow border border-slate-100 flex flex-col justify-between"
              >
                {/* Image block with Category badge */}
                <div className="h-48 overflow-hidden relative bg-slate-100">
                  <img 
                    src={p.image} 
                    alt={p.title} 
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-3 left-3 bg-[#ea580c] text-white px-2.5 py-0.5 rounded-full text-xs font-display font-semibold tracking-wide">
                    {p.category}
                  </div>
                </div>

                {/* Info block */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div className="space-y-3">
                    <h3 className="font-display font-bold text-xl text-slate-800 leading-tight">
                      {p.title}
                    </h3>
                    <p className="text-xs md:text-sm text-slate-500 leading-relaxed line-clamp-3">
                      {p.description}
                    </p>
                  </div>

                  {/* Progress Bar & Stats */}
                  <div className="mt-6 space-y-2">
                    <div className="flex justify-between items-end text-xs font-semibold text-slate-500">
                      <span>Progress ({pct}%)</span>
                      <span className="font-mono text-slate-700">
                        ${p.raised.toLocaleString()} / <span className="text-slate-400">${p.goal.toLocaleString()}</span>
                      </span>
                    </div>

                    {/* Outer Progress Bar container */}
                    <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden border border-slate-200/50">
                      <motion.div 
                        className="h-full bg-linear-to-r from-[#ea580c] to-amber-500 rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: `${pct}%` }}
                        transition={{ duration: 0.8, ease: "easeOut" }}
                      />
                    </div>

                    <div className="flex justify-between items-center pt-2 text-[11px] text-slate-400">
                      <span className="flex items-center gap-1">
                        <Heart size={12} className="text-rose-400 fill-rose-400" />
                        <strong>{p.donorsCount}</strong> supporters
                      </span>
                      <span>501(c)(3) tax exempt</span>
                    </div>
                  </div>

                  {/* Action Button */}
                  <div className="mt-5 pt-4 border-t border-slate-100 flex justify-end">
                    <motion.button
                      id={`btn-support-${p.id}`}
                      onClick={() => handleOpenDonateModal(p)}
                      className="bg-[#ea580c] text-white px-5 py-2 rounded-xl font-display font-semibold text-sm flex items-center gap-2 shadow-xs hover:bg-[#c2410c] cursor-pointer select-none"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Heart size={14} className="fill-white" />
                      <span>Support Fund</span>
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Donation Dialog Modal */}
      <AnimatePresence>
        {selectedProject && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={handleCloseDonateModal}
              className="absolute inset-0 bg-slate-950/60 backdrop-blur-xs"
            />

            {/* Modal Body */}
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              transition={{ type: "spring", duration: 0.4 }}
              className="relative bg-white w-full max-w-lg rounded-2xl shadow-xl overflow-hidden z-10 border border-slate-100 flex flex-col"
            >
              {/* Header */}
              <div className="bg-[#ea580c] text-white p-5 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Heart size={20} className="fill-white" />
                  <h3 className="font-display font-bold text-lg md:text-xl">
                    Support {selectedProject.category}
                  </h3>
                </div>
                <button 
                  onClick={handleCloseDonateModal}
                  className="text-white/80 hover:text-white p-1 rounded-full hover:bg-white/10 transition-colors cursor-pointer select-none"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Form & Flow */}
              <div className="p-6 overflow-y-auto max-h-[80vh] font-sans">
                {!isSuccess ? (
                  <form onSubmit={handleSubmitDonation} className="space-y-5">
                    
                    {/* Project Title Callout */}
                    <div className="bg-orange-50/70 p-3.5 rounded-xl border border-orange-100/50 text-xs md:text-sm text-slate-700">
                      <span className="font-bold text-[#ea580c]">Directing to: </span>
                      {selectedProject.title}
                    </div>

                    {/* Donor Details */}
                    <div className="space-y-3.5">
                      <h4 className="font-display font-semibold text-xs md:text-sm text-slate-700 uppercase tracking-wider">
                        1. Donor Information
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="relative">
                          <User size={16} className="absolute left-3 top-3 text-slate-400" />
                          <input
                            type="text"
                            required
                            placeholder="Full Name"
                            value={donorName}
                            onChange={(e) => setDonorName(e.target.value)}
                            className="pl-9.5 pr-4 py-2.5 w-full bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-[#ea580c] focus:bg-white transition-all"
                          />
                        </div>
                        <div className="relative">
                          <Mail size={16} className="absolute left-3 top-3 text-slate-400" />
                          <input
                            type="email"
                            required
                            placeholder="Email Address"
                            value={donorEmail}
                            onChange={(e) => setDonorEmail(e.target.value)}
                            className="pl-9.5 pr-4 py-2.5 w-full bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-[#ea580c] focus:bg-white transition-all"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Amount Selector */}
                    <div className="space-y-3.5">
                      <h4 className="font-display font-semibold text-xs md:text-sm text-slate-700 uppercase tracking-wider">
                        2. Select Donation Amount
                      </h4>
                      <div className="grid grid-cols-4 gap-2">
                        {['10', '25', '50', '100'].map((amt) => {
                          const isSelected = donationAmount === amt;
                          return (
                            <button
                              key={amt}
                              type="button"
                              onClick={() => handleAmountSelect(amt)}
                              className={`
                                py-2 rounded-xl text-center font-display font-bold text-sm cursor-pointer border select-none transition-all
                                ${isSelected 
                                  ? 'bg-[#ea580c] text-white border-[#ea580c] shadow-xs' 
                                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'}
                              `}
                            >
                              ${amt}
                            </button>
                          );
                        })}
                      </div>

                      {/* Custom Amount input */}
                      <div className="relative">
                        <DollarSign size={16} className="absolute left-3 top-3 text-slate-500 font-bold" />
                        <input
                          type="number"
                          placeholder="Or enter custom USD amount"
                          value={customAmount}
                          onChange={handleCustomAmountChange}
                          className="pl-8 pr-4 py-2.5 w-full bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-[#ea580c] focus:bg-white transition-all font-semibold text-slate-700"
                        />
                      </div>
                    </div>

                    {/* Mock Billing/Credit Card */}
                    <div className="space-y-3.5 pt-1.5">
                      <h4 className="font-display font-semibold text-xs md:text-sm text-slate-700 uppercase tracking-wider">
                        3. Secure Billing Information
                      </h4>
                      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                        <div className="relative">
                          <CreditCard size={16} className="absolute left-3 top-3.5 text-slate-400" />
                          <input
                            type="text"
                            required
                            maxLength={19}
                            placeholder="Card Number (e.g. 4000 1234 5678 9010)"
                            value={cardNumber}
                            onChange={(e) => setCardNumber(e.target.value.replace(/\s?/g, '').replace(/(\d{4})/g, '$1 ').trim())}
                            className="pl-9.5 pr-4 py-2.5 w-full bg-white border border-slate-200 rounded-lg text-sm focus:outline-hidden focus:ring-2 focus:ring-[#ea580c] transition-all font-mono"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <input
                            type="text"
                            required
                            maxLength={5}
                            placeholder="MM/YY"
                            value={cardExpiry}
                            onChange={(e) => setCardExpiry(e.target.value)}
                            className="px-3 py-2.5 w-full bg-white border border-slate-200 rounded-lg text-sm focus:outline-hidden focus:ring-2 focus:ring-[#ea580c] transition-all font-mono text-center"
                          />
                          <input
                            type="password"
                            required
                            maxLength={3}
                            placeholder="CVC"
                            value={cardCvc}
                            onChange={(e) => setCardCvc(e.target.value)}
                            className="px-3 py-2.5 w-full bg-white border border-slate-200 rounded-lg text-sm focus:outline-hidden focus:ring-2 focus:ring-[#ea580c] transition-all font-mono text-center"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Submit Row */}
                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
                      <div className="flex items-center gap-1">
                        <ShieldCheck size={14} className="text-emerald-500" />
                        <span>Secure 256-bit SSL</span>
                      </div>
                      <motion.button
                        id="submit-donation-btn"
                        type="submit"
                        disabled={isSubmitting}
                        className="bg-[#ea580c] hover:bg-[#c2410c] text-white px-6 py-3 rounded-xl font-display font-bold text-sm shadow-md cursor-pointer select-none disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                        whileHover={{ scale: 1.03 }}
                        whileTap={{ scale: 0.97 }}
                      >
                        {isSubmitting ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                            <span>Processing...</span>
                          </>
                        ) : (
                          <>
                            <Heart size={14} className="fill-white" />
                            <span>Donate Now</span>
                          </>
                        )}
                      </motion.button>
                    </div>
                  </form>
                ) : (
                  /* Success Screen */
                  <motion.div
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="py-10 text-center space-y-5"
                  >
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: [0, 1.2, 1] }}
                      transition={{ duration: 0.5, type: "spring" }}
                      className="inline-flex items-center justify-center p-4 bg-emerald-50 rounded-full border-2 border-emerald-100 text-emerald-500 mb-2"
                    >
                      <CheckCircle2 size={48} className="stroke-[2]" />
                    </motion.div>

                    <h4 className="font-display font-bold text-2xl text-slate-800">
                      Thank You, {donorName}!
                    </h4>
                    
                    <p className="text-xs md:text-sm text-slate-500 max-w-sm mx-auto leading-relaxed">
                      Your generous support of <strong className="text-slate-800 font-bold">${donationAmount === 'custom' ? customAmount : donationAmount}</strong> has been processed successfully. We have sent a tax-exempt receipt to <strong className="text-slate-800">{donorEmail}</strong>.
                    </p>

                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 max-w-sm mx-auto text-left space-y-2">
                      <div className="flex justify-between text-xs text-slate-500">
                        <span>Transaction ID:</span>
                        <span className="font-mono text-slate-700">#CH-{Math.floor(Math.random() * 900000 + 100000)}</span>
                      </div>
                      <div className="flex justify-between text-xs text-slate-500">
                        <span>Fund Allocated:</span>
                        <span className="font-bold text-slate-700">{selectedProject.title}</span>
                      </div>
                      <div className="flex justify-between text-xs text-slate-500">
                        <span>Tax Status:</span>
                        <span className="text-emerald-600 font-bold">501(c)(3) Exempt</span>
                      </div>
                    </div>

                    <div className="pt-4">
                      <motion.button
                        id="success-done-btn"
                        onClick={handleCloseDonateModal}
                        className="bg-slate-800 text-white px-6 py-2 rounded-xl text-sm font-display font-medium shadow-xs hover:bg-slate-900 cursor-pointer select-none"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        Back to Charities
                      </motion.button>
                    </div>
                  </motion.div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
