import { motion } from 'motion/react';
import { Handshake, Heart, Lightbulb, ArrowRight } from 'lucide-react';
import { FEATURE_BOXES } from '../data';

interface FeatureBlocksProps {
  onNavigate: (tabId: string) => void;
}

export default function FeatureBlocks({ onNavigate }: FeatureBlocksProps) {
  // Map icons dynamically
  const getIcon = (iconName: string, color: string) => {
    switch (iconName) {
      case 'handshake':
        return <Handshake size={48} className={`${color} stroke-[1.5]`} />;
      case 'heart':
        return <Heart size={48} className={`${color} stroke-[1.5] fill-white/10`} />;
      case 'lightbulb':
        default:
        return <Lightbulb size={48} className={`${color} stroke-[1.5]`} />;
    }
  };

  // Map box actions to corresponding main navigation tabs
  const getTabId = (boxId: string) => {
    if (boxId === 'mission') return 'about';
    if (boxId === 'donations') return 'charities';
    return 'programs';
  };

  return (
    <div id="feature-blocks-grid" className="grid grid-cols-1 md:grid-cols-3 gap-6 my-6">
      {FEATURE_BOXES.map((box, index) => {
        const targetTab = getTabId(box.id);
        
        return (
          <motion.div
            key={box.id}
            id={`feature-box-${box.id}`}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ type: "spring", stiffness: 100, delay: index * 0.1 }}
            whileHover={{ 
              y: -8,
              scale: 1.02,
              boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.15)"
            }}
            className={`
              ${box.bgColor} text-white p-6 rounded-2xl flex flex-col justify-between shadow-md relative overflow-hidden group border-2 border-white/20
            `}
          >
            {/* Background design accents */}
            <div className="absolute -right-6 -bottom-6 w-32 h-32 bg-white/5 rounded-full group-hover:scale-150 transition-transform duration-500" />
            <div className="absolute -left-6 -top-6 w-20 h-20 bg-black/5 rounded-full" />

            <div>
              {/* Header block with Icon */}
              <div className="flex items-center gap-4 mb-4">
                <motion.div 
                  className="p-3 bg-white/20 rounded-2xl backdrop-blur-xs flex items-center justify-center shadow-inner"
                  whileHover={{ rotate: [0, -10, 10, -10, 0] }}
                  transition={{ duration: 0.5 }}
                >
                  {getIcon(box.icon, "text-white")}
                </motion.div>
                <h3 className="font-display font-bold text-2xl md:text-3xl leading-tight tracking-wide drop-shadow-sm select-none">
                  {box.title}
                </h3>
              </div>

              {/* Description */}
              <p className="text-sm leading-relaxed text-white/95 font-sans mb-6">
                {box.description}
              </p>
            </div>

            {/* "More" Button style matching image */}
            <div className="flex justify-end mt-auto">
              <motion.button
                id={`btn-more-${box.id}`}
                onClick={() => onNavigate(targetTab)}
                className={`
                  ${box.btnColor} px-6 py-2 rounded-xl text-white font-display font-medium flex items-center gap-1.5 shadow-sm border border-white/20 cursor-pointer select-none
                `}
                whileHover={{ scale: 1.1, x: 3 }}
                whileTap={{ scale: 0.95 }}
              >
                <span>more</span>
                <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
              </motion.button>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
