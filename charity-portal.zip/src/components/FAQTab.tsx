import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { FAQS } from '../data';
import { Search, HelpCircle, ChevronDown, Award } from 'lucide-react';

export default function FAQTab() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const categories = ['all', 'donations', 'volunteering', 'programs', 'general'];

  const handleToggle = (id: number) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const filteredFaqs = FAQS.filter(faq => {
    const matchesCategory = selectedCategory === 'all' || faq.category === selectedCategory;
    const matchesSearch = faq.question.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.3 }}
      className="space-y-6"
    >
      {/* Search and Category Control Card */}
      <div className="bg-white rounded-2xl p-6 shadow-md border-b-4 border-slate-200 space-y-5">
        <h2 className="font-display font-bold text-3xl text-[#eab308] mb-1">
          Frequently Asked Questions
        </h2>
        <p className="text-xs md:text-sm text-slate-400 font-sans max-w-xl">
          Find instant answers regarding donations, tax exemptions, preschool enrollment, or facility visits.
        </p>

        <div className="flex flex-col sm:flex-row gap-3.5 pt-2">
          {/* Search bar */}
          <div className="relative flex-1">
            <Search size={18} className="absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              placeholder="Search questions or keywords..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2.5 w-full bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-[#eab308] focus:bg-white transition-all font-medium text-slate-700"
            />
          </div>

          {/* Category Pill Filters */}
          <div className="flex flex-wrap gap-1.5 self-center">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`
                  px-3.5 py-1.5 rounded-lg text-xs font-display font-semibold transition-all capitalize cursor-pointer select-none
                  ${selectedCategory === cat
                    ? 'bg-[#eab308] text-slate-900 shadow-xs'
                    : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}
                `}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Accordion Questions List */}
      <div className="space-y-3.5 max-w-3xl mx-auto">
        <AnimatePresence mode="popLayout">
          {filteredFaqs.length > 0 ? (
            filteredFaqs.map((faq) => {
              const isExpanded = expandedId === faq.id;
              
              return (
                <motion.div
                  key={faq.id}
                  id={`faq-accordion-${faq.id}`}
                  layout
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.98 }}
                  className="bg-white rounded-xl border border-slate-100 shadow-xs overflow-hidden"
                >
                  {/* Trigger Header */}
                  <button
                    onClick={() => handleToggle(faq.id)}
                    className="w-full flex items-center justify-between p-4 md:p-5 text-left cursor-pointer hover:bg-slate-50/50 transition-colors select-none group"
                  >
                    <div className="flex items-center gap-3.5 pr-4">
                      <HelpCircle size={20} className="text-[#eab308] shrink-0" />
                      <span className="font-display font-bold text-slate-800 text-sm md:text-base leading-tight group-hover:text-slate-900">
                        {faq.question}
                      </span>
                    </div>
                    <motion.div
                      animate={{ rotate: isExpanded ? 180 : 0 }}
                      transition={{ duration: 0.25 }}
                      className="text-slate-400 shrink-0 bg-slate-50 p-1.5 rounded-full"
                    >
                      <ChevronDown size={16} />
                    </motion.div>
                  </button>

                  {/* Collapsible content */}
                  <AnimatePresence initial={false}>
                    {isExpanded && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3, ease: "easeInOut" }}
                        className="border-t border-slate-50 bg-slate-50/40"
                      >
                        <div className="p-5 font-sans text-xs md:text-sm text-slate-600 leading-relaxed space-y-2">
                          <p>{faq.answer}</p>
                          <div className="flex items-center gap-1.5 pt-2">
                            <span className="bg-amber-50 text-[#ca8a04] px-2 py-0.5 rounded-md text-[10px] font-bold font-display uppercase tracking-wider">
                              Category: {faq.category}
                            </span>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })
          ) : (
            <motion.div
              layout
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-12 bg-white rounded-xl border border-slate-100"
            >
              <p className="text-slate-400 font-medium font-sans">
                No FAQ matches your search query. Try typing another keyword.
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Trust Badge at footer */}
      <div className="flex justify-center pt-4">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-50 rounded-full border border-emerald-100 text-emerald-600 text-xs font-semibold">
          <Award size={15} />
          <span>Awarded Glasgow's Top Transparent Children's Charity 2026</span>
        </div>
      </div>
    </motion.div>
  );
}
