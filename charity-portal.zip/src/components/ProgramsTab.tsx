import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PROGRAMS } from '../data';
import { Calendar, Clock, Smile, Sparkles, Send, CheckCircle2, AlertCircle } from 'lucide-react';

export default function ProgramsTab() {
  // Enrollment Inquiry Form States
  const [childName, setChildName] = useState('');
  const [childAge, setChildAge] = useState('');
  const [parentName, setParentName] = useState('');
  const [parentPhone, setParentPhone] = useState('');
  const [selectedProgram, setSelectedProgram] = useState(PROGRAMS[0].id);
  const [specialNotes, setSpecialNotes] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmitInquiry = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate server submission
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      // Reset form
      setChildName('');
      setChildAge('');
      setParentName('');
      setParentPhone('');
      setSpecialNotes('');
    }, 1200);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.3 }}
      className="space-y-8"
    >
      {/* Intro Header */}
      <div className="bg-white rounded-2xl p-6 shadow-md border-b-4 border-slate-200">
        <h2 className="font-display font-bold text-3xl text-[#2563eb] mb-3">
          Our Educational & Care Programs
        </h2>
        <p className="text-sm md:text-base text-slate-500 max-w-2xl leading-relaxed">
          We offer diverse age-appropriate programs that cultivate self-expression, cognitive foundations, physical development, and healthy community habits.
        </p>
      </div>

      {/* Grid of Programs */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {PROGRAMS.map((prog, idx) => (
          <motion.div
            key={prog.id}
            id={`program-card-${prog.id}`}
            className="bg-white rounded-2xl overflow-hidden shadow-md border border-slate-100 flex flex-col md:flex-row"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            whileHover={{ y: -4, boxShadow: "0 12px 20px -8px rgba(0,0,0,0.15)" }}
          >
            {/* Left Image block */}
            <div className="w-full md:w-2/5 h-48 md:h-auto relative bg-slate-100">
              <img 
                src={prog.image} 
                alt={prog.title} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-3 left-3 bg-[#2563eb] text-white px-2.5 py-0.5 rounded-full text-xs font-semibold uppercase tracking-wider">
                {prog.ageGroup}
              </div>
            </div>

            {/* Right details block */}
            <div className="w-full md:w-3/5 p-5 flex flex-col justify-between">
              <div className="space-y-3">
                <h3 className="font-display font-bold text-lg text-slate-800 leading-tight">
                  {prog.title}
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed line-clamp-4">
                  {prog.description}
                </p>
              </div>

              {/* Badges and metadata */}
              <div className="mt-4 pt-3 border-t border-slate-50 space-y-1.5 text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <Clock size={12} className="text-[#2563eb]" />
                  <span>{prog.duration}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar size={12} className="text-[#2563eb]" />
                  <span>{prog.schedule}</span>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Parental Enrollment Inquiry Form Container */}
      <div className="bg-slate-50 rounded-2xl border border-slate-200 p-6 md:p-8 max-w-2xl mx-auto">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="text-[#2563eb] animate-pulse" />
          <h3 className="font-display font-bold text-2xl text-slate-800">
            Pre-Enrollment Inquiry Form
          </h3>
        </div>
        <p className="text-xs md:text-sm text-slate-500 mb-6 leading-relaxed">
          Would you like to register your child or schedule an introduction? Fill out this quick pre-enrollment questionnaire and our program coordinator will phone you back within 24 hours.
        </p>

        <AnimatePresence mode="wait">
          {!isSuccess ? (
            <motion.form
              key="enroll-form"
              onSubmit={handleSubmitInquiry}
              className="space-y-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Child Name */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Child's Name</label>
                  <input
                    type="text"
                    required
                    placeholder="E.g., Leo Jenkins"
                    value={childName}
                    onChange={(e) => setChildName(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-[#2563eb] transition-all"
                  />
                </div>

                {/* Child Age */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Child's Age</label>
                  <input
                    type="number"
                    required
                    min={1}
                    max={15}
                    placeholder="E.g., 4"
                    value={childAge}
                    onChange={(e) => setChildAge(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-[#2563eb] transition-all"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Parent Name */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Parent/Guardian Name</label>
                  <input
                    type="text"
                    required
                    placeholder="E.g., Sarah Jenkins"
                    value={parentName}
                    onChange={(e) => setParentName(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-[#2563eb] transition-all"
                  />
                </div>

                {/* Parent Phone */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Contact Phone</label>
                  <input
                    type="tel"
                    required
                    placeholder="E.g., +44 7700 900077"
                    value={parentPhone}
                    onChange={(e) => setParentPhone(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-[#2563eb] transition-all"
                  />
                </div>
              </div>

              {/* Target Program Selection */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Desired Program</label>
                <select
                  value={selectedProgram}
                  onChange={(e) => setSelectedProgram(e.target.value)}
                  className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-[#2563eb] transition-all text-slate-700 font-medium"
                >
                  {PROGRAMS.map(p => (
                    <option key={p.id} value={p.id}>{p.title} ({p.ageGroup})</option>
                  ))}
                </select>
              </div>

              {/* Special dietary/medical/cooperation notes */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Special Requests / Notes</label>
                <textarea
                  rows={3}
                  placeholder="Any dietary needs, learning conditions, or timing restrictions..."
                  value={specialNotes}
                  onChange={(e) => setSpecialNotes(e.target.value)}
                  className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-[#2563eb] transition-all text-slate-700"
                />
              </div>

              {/* Submit button */}
              <div className="flex justify-end pt-2">
                <motion.button
                  id="submit-inquiry-btn"
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-[#2563eb] hover:bg-[#1d4ed8] text-white px-6 py-2.5 rounded-xl font-display font-bold text-sm shadow-md cursor-pointer flex items-center gap-2 select-none disabled:opacity-50"
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                >
                  {isSubmitting ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                      <span>Sending inquiry...</span>
                    </>
                  ) : (
                    <>
                      <Send size={14} />
                      <span>Submit Request</span>
                    </>
                  )}
                </motion.button>
              </div>
            </motion.form>
          ) : (
            <motion.div
              key="enroll-success"
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-center py-8 space-y-4"
            >
              <div className="inline-flex items-center justify-center p-3.5 bg-emerald-50 rounded-full text-emerald-500 border border-emerald-100">
                <CheckCircle2 size={36} />
              </div>
              <h4 className="font-display font-bold text-xl text-slate-800">
                Inquiry Sent Successfully!
              </h4>
              <p className="text-xs md:text-sm text-slate-500 max-w-sm mx-auto leading-relaxed">
                Thank you for reaching out, <strong>{parentName}</strong>. We have registered your pre-enrollment request for <strong>{childName}</strong>. Our director of early learning will phone you at <strong>{parentPhone}</strong> shortly.
              </p>
              <div className="pt-2">
                <button
                  onClick={() => setIsSuccess(false)}
                  className="bg-slate-800 hover:bg-slate-900 text-white px-5 py-2 rounded-xl text-xs font-display font-medium cursor-pointer select-none"
                >
                  Submit Another Inquiry
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
