import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CAROUSEL_SLIDES } from '../data';
import { ChevronLeft, ChevronRight } from 'lucide-react';

export default function HeroCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0); // -1 for left, 1 for right

  useEffect(() => {
    const timer = setInterval(() => {
      handleNext();
    }, 6000);
    return () => clearInterval(timer);
  }, [currentIndex]);

  const handleNext = () => {
    setDirection(1);
    setCurrentIndex((prev) => (prev + 1) % CAROUSEL_SLIDES.length);
  };

  const handlePrev = () => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev - 1 + CAROUSEL_SLIDES.length) % CAROUSEL_SLIDES.length);
  };

  const handleDotClick = (index: number) => {
    setDirection(index > currentIndex ? 1 : -1);
    setCurrentIndex(index);
  };

  // Slider animation variants
  const slideVariants = {
    enter: (dir: number) => ({
      x: dir > 0 ? 1000 : -1000,
      opacity: 0
    }),
    center: {
      x: 0,
      opacity: 1
    },
    exit: (dir: number) => ({
      x: dir < 0 ? 1000 : -1000,
      opacity: 0
    })
  };

  const currentSlide = CAROUSEL_SLIDES[currentIndex];

  return (
    <div id="hero-carousel-container" className="relative w-full overflow-hidden bg-sky-950 aspect-[2.1/1] sm:aspect-[2.4/1] md:aspect-[2.8/1] rounded-2xl border-4 border-white shadow-lg">
      <AnimatePresence initial={false} custom={direction}>
        <motion.div
          key={currentIndex}
          custom={direction}
          variants={slideVariants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{
            x: { type: "spring", stiffness: 300, damping: 30 },
            opacity: { duration: 0.3 }
          }}
          className="absolute inset-0 w-full h-full"
        >
          {/* Main Slide Image */}
          <img
            src={currentSlide.image}
            alt={currentSlide.title}
            className="w-full h-full object-cover object-center select-none"
            referrerPolicy="no-referrer"
          />

          {/* Gradients & Caption Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex flex-col justify-end p-4 sm:p-6 md:p-8">
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.1, duration: 0.4 }}
              className="max-w-2xl text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]"
            >
              <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold tracking-wide text-[#0096d9] drop-shadow-[0_1.5px_0_white]">
                {currentSlide.title}
              </h2>
              <p className="mt-1 sm:mt-2 text-xs sm:text-sm md:text-base leading-relaxed text-gray-100 font-sans max-w-xl line-clamp-2 sm:line-clamp-none">
                {currentSlide.subtitle}
              </p>
            </motion.div>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Slide Navigation Arrows */}
      <button
        id="carousel-btn-prev"
        onClick={handlePrev}
        className="absolute left-3 top-1/2 -translate-y-1/2 p-1.5 sm:p-2 rounded-full bg-black/40 text-white/80 hover:bg-black/60 hover:text-white transition-colors cursor-pointer backdrop-blur-xs select-none"
      >
        <ChevronLeft size={20} className="w-5 h-5 sm:w-6 sm:h-6" />
      </button>
      <button
        id="carousel-btn-next"
        onClick={handleNext}
        className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 sm:p-2 rounded-full bg-black/40 text-white/80 hover:bg-black/60 hover:text-white transition-colors cursor-pointer backdrop-blur-xs select-none"
      >
        <ChevronRight size={20} className="w-5 h-5 sm:w-6 sm:h-6" />
      </button>

      {/* Styled Dot Indicators exactly positioned as in screenshot bottom-right */}
      <div id="carousel-dots-container" className="absolute bottom-4 right-4 flex items-center gap-2 bg-black/40 px-3 py-1.5 rounded-full backdrop-blur-xs">
        {CAROUSEL_SLIDES.map((slide, idx) => {
          const isActive = idx === currentIndex;
          // Colors matching the original dots in the screenshot: blue, orange, yellow, white
          const dotColorClasses = [
            "bg-[#3b82f6]", // Blue
            "bg-[#f97316]", // Orange
            "bg-[#eab308]", // Yellow
            "bg-white"      // White
          ];
          const dotColor = dotColorClasses[idx % dotColorClasses.length];

          return (
            <button
              key={slide.id}
              onClick={() => handleDotClick(idx)}
              className={`
                h-3 w-3 rounded-full cursor-pointer transition-all duration-300 border border-white/50
                ${dotColor}
                ${isActive ? 'scale-130 ring-2 ring-white ring-offset-1 ring-offset-transparent' : 'opacity-60 scale-100'}
              `}
              title={`Go to slide ${idx + 1}`}
            />
          );
        })}
      </div>
    </div>
  );
}
