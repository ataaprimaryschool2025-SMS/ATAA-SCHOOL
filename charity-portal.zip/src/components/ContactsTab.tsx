import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Phone, MapPin, Clock, Send, MessageSquare, CheckSquare, Sparkles } from 'lucide-react';

export default function ContactsTab() {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('general');
  const [message, setMessage] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmitMessage = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate server submission
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      // Reset
      setFullName('');
      setEmail('');
      setMessage('');
    }, 1200);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.3 }}
      className="space-y-8"
    >
      {/* Intro Header */}
      <div className="bg-white rounded-2xl p-6 shadow-md border-b-4 border-slate-200">
        <h2 className="font-display font-bold text-3xl text-[#16a34a] mb-3">
          Get in Touch with Our Team
        </h2>
        <p className="text-sm md:text-base text-slate-500 max-w-2xl leading-relaxed">
          Have queries about sponsorship opportunities, corporate grants, or volunteering in Glasgow classrooms? Send us an instant message or visit our local administrative facility.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
        {/* Left Column: Direct info & Map visual (5 cols) */}
        <div className="md:col-span-5 space-y-6">
          {/* Quick Contacts Box */}
          <div className="bg-white rounded-2xl p-6 shadow-xs border border-slate-100 space-y-5">
            <h3 className="font-display font-bold text-xl text-slate-800">
              Facility Coordinates
            </h3>
            
            <div className="space-y-4 text-xs md:text-sm text-slate-600">
              <div className="flex items-start gap-3">
                <MapPin size={18} className="text-[#16a34a] shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-slate-800 font-bold">Main Facility Address:</strong>
                  <span>8901 Marmora Road, Glasgow, D04 89GR</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone size={18} className="text-[#16a34a] shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-slate-800 font-bold">Inquiry Telephone:</strong>
                  <span className="font-semibold text-slate-800">1-234-567-8097</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Mail size={18} className="text-[#16a34a] shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-slate-800 font-bold">Email Inbox:</strong>
                  <span className="text-[#16a34a] hover:underline cursor-pointer">primarycare2026@charitynet.org</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock size={18} className="text-[#16a34a] shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-slate-800 font-bold">Operational Hours:</strong>
                  <span>Mon - Fri: 8:00 AM - 5:30 PM</span>
                  <span className="block text-slate-400 text-[11px] italic">Closed on Saturdays & Sundays</span>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Glasgow Styled Map Vector */}
          <div className="bg-sky-50 rounded-2xl p-5 border border-sky-100 relative overflow-hidden h-64 shadow-xs flex flex-col justify-between">
            {/* Map Grid overlay */}
            <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#0369a1_1px,transparent_1px)] [background-size:16px_16px]" />
            
            {/* Stylized streets */}
            <div className="absolute w-full h-4 bg-sky-200/50 top-1/4 -rotate-3" />
            <div className="absolute w-full h-6 bg-sky-200/50 top-2/3 rotate-6" />
            <div className="absolute h-full w-5 bg-sky-200/50 left-1/3 rotate-12" />
            <div className="absolute h-full w-4 bg-sky-200/50 left-2/3 -rotate-12" />

            <div className="relative">
              <span className="bg-sky-100 text-sky-700 px-2.5 py-1 rounded-full text-[10px] font-bold font-mono tracking-wider uppercase">
                Glasgow Facility Area
              </span>
            </div>

            {/* Glowing Map Pin */}
            <div className="absolute left-[45%] top-[45%] -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
              <motion.div
                animate={{ y: [0, -6, 0] }}
                transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
                className="z-10"
              >
                <MapPin size={32} className="text-rose-500 fill-rose-500 stroke-white stroke-2" />
              </motion.div>
              {/* Ripple Ring */}
              <div className="w-8 h-2.5 bg-black/15 rounded-full blur-xs mt-0.5 scale-x-120" />
            </div>

            <div className="relative text-[11px] text-sky-600 bg-white/80 p-2.5 rounded-lg border border-sky-100/50 backdrop-blur-xs">
              <strong className="block text-sky-950">Marmora Road Preschool</strong>
              <span>Near Queens Park, Glasgow</span>
            </div>
          </div>
        </div>

        {/* Right Column: Contact form (7 cols) */}
        <div className="md:col-span-7 bg-white rounded-2xl p-6 md:p-8 shadow-xs border border-slate-100">
          <div className="flex items-center gap-2 mb-6">
            <MessageSquare className="text-[#16a34a]" />
            <h3 className="font-display font-bold text-xl text-slate-800">
              Send an Instant Message
            </h3>
          </div>

          <AnimatePresence mode="wait">
            {!isSuccess ? (
              <motion.form
                key="contact-form"
                onSubmit={handleSubmitMessage}
                className="space-y-4"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                {/* Full name input */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Your Full Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Enter your first and last name"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-[#16a34a] focus:bg-white transition-all text-slate-700"
                  />
                </div>

                {/* Email address */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Email Address</label>
                  <input
                    type="email"
                    required
                    placeholder="E.g., you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-[#16a34a] focus:bg-white transition-all text-slate-700"
                  />
                </div>

                {/* Inquiry subject */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Inquiry Subject</label>
                  <select
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-[#16a34a] focus:bg-white transition-all text-slate-700 font-medium"
                  >
                    <option value="general">General Inquiries / Support</option>
                    <option value="volunteering">Volunteering Opportunities</option>
                    <option value="sponsorship">Corporate Sponsorship / Funding</option>
                    <option value="enrollment">Preschool Enrollment Assistance</option>
                  </select>
                </div>

                {/* Message text */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Your Message</label>
                  <textarea
                    rows={5}
                    required
                    placeholder="Write details of your message here..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-[#16a34a] focus:bg-white transition-all text-slate-700"
                  />
                </div>

                {/* Submit row */}
                <div className="flex justify-end pt-2">
                  <motion.button
                    id="contact-submit-btn"
                    type="submit"
                    disabled={isSubmitting}
                    className="bg-[#16a34a] hover:bg-[#15803d] text-white px-6 py-2.5 rounded-xl font-display font-bold text-sm shadow-md cursor-pointer flex items-center gap-2 select-none disabled:opacity-50"
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                  >
                    {isSubmitting ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                        <span>Sending Message...</span>
                      </>
                    ) : (
                      <>
                        <Send size={14} />
                        <span>Send Message</span>
                      </>
                    )}
                  </motion.button>
                </div>
              </motion.form>
            ) : (
              <motion.div
                key="contact-success"
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ opacity: 0 }}
                className="text-center py-12 space-y-4"
              >
                <div className="inline-flex items-center justify-center p-3.5 bg-emerald-50 rounded-full text-emerald-500 border border-emerald-100">
                  <Sparkles size={36} className="animate-pulse" />
                </div>
                <h4 className="font-display font-bold text-xl text-slate-800">
                  Message Dispatched!
                </h4>
                <p className="text-xs md:text-sm text-slate-500 max-w-sm mx-auto leading-relaxed">
                  Thank you for your message, <strong>{fullName}</strong>. A staff representative will review your inquiry regarding <strong>{subject === 'general' ? 'general support' : subject}</strong> and contact you at <strong>{email}</strong> shortly.
                </p>
                <div className="pt-2">
                  <button
                    onClick={() => setIsSuccess(false)}
                    className="bg-slate-800 hover:bg-slate-900 text-white px-5 py-2 rounded-xl text-xs font-display font-medium cursor-pointer select-none"
                  >
                    Send Another Message
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
}
