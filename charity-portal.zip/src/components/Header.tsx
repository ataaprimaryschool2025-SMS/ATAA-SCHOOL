import { motion } from 'motion/react';
import { Phone, MapPin } from 'lucide-react';

interface HeaderProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
}

export default function Header({ currentTab, setCurrentTab }: HeaderProps) {
  const navItems = [
    { id: 'home', label: 'Home', color: 'bg-[#a21caf] hover:bg-[#86198f]' }, // Purple-magenta
    { id: 'about', label: 'About', color: 'bg-[#dc2626] hover:bg-[#b91c1c]' }, // Red
    { id: 'charities', label: 'Our Charities', color: 'bg-[#ea580c] hover:bg-[#c2410c]' }, // Orange
    { id: 'programs', label: 'Programs', color: 'bg-[#2563eb] hover:bg-[#1d4ed8]' }, // Cyan-blue
    { id: 'faqs', label: 'FAQs', color: 'bg-[#eab308] hover:bg-[#ca8a04]' }, // Yellow/Amber
    { id: 'contacts', label: 'Contacts', color: 'bg-[#16a34a] hover:bg-[#15803d]' }, // Green
    { id: 'staff', label: 'Staff Portal', color: 'bg-[#6b21a8] hover:bg-[#581c87]' }, // Royal Purple
  ];

  return (
    <header className="bg-[#0096d9] text-white py-4 px-4 md:px-8 border-b-4 border-white/20 shadow-md">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        
        {/* Contact Info Top Right Style */}
        <div className="md:order-2 flex flex-col sm:flex-row items-start sm:items-center gap-4 text-xs font-medium md:self-start opacity-90">
          <div className="flex items-center gap-1.5">
            <MapPin size={13} className="text-white/80" />
            <span>8901 Marmora Road, Glasgow, D04 89GR</span>
          </div>
          <div className="flex items-center gap-1.5 font-bold">
            <Phone size={13} className="text-white/80" />
            <span>Tel: 1-234-567-8097</span>
          </div>
        </div>

        {/* Logo and Playful Font */}
        <div className="md:order-1 flex flex-col sm:flex-row sm:items-end gap-3">
          <motion.h1 
            id="app-logo"
            className="font-display font-bold text-5xl md:text-6xl tracking-wide select-none cursor-pointer text-white drop-shadow-[0_3px_0_rgba(0,0,0,0.25)]"
            initial={{ scale: 0.95, y: -5 }}
            animate={{ scale: 1, y: 0 }}
            transition={{ 
              type: "spring",
              stiffness: 260,
              damping: 10,
              repeat: Infinity,
              repeatType: "reverse",
              duration: 2.5
            }}
            onClick={() => setCurrentTab('home')}
          >
            Charity
          </motion.h1>
          <span className="text-xs tracking-wider opacity-80 uppercase font-bold mb-1.5 font-sans">
            Children's Support Network
          </span>
        </div>

      </div>

      {/* Navigation Buttons Row exactly matching image */}
      <div className="max-w-6xl mx-auto mt-6 flex flex-wrap gap-2 md:gap-3">
        {navItems.map((item) => {
          const isActive = currentTab === item.id;
          return (
            <motion.button
              key={item.id}
              id={`nav-${item.id}`}
              onClick={() => setCurrentTab(item.id)}
              className={`
                px-5 py-2.5 rounded-xl font-display font-medium text-lg md:text-xl text-white tracking-wide shadow-sm transition-all duration-200 cursor-pointer
                ${item.color}
                ${isActive ? 'ring-4 ring-white scale-105 shadow-md font-bold' : 'scale-100'}
              `}
              whileHover={{ 
                scale: 1.08, 
                y: -3,
                boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.2)"
              }}
              whileTap={{ scale: 0.96 }}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 15 }}
            >
              {item.label}
            </motion.button>
          );
        })}
      </div>
    </header>
  );
}
