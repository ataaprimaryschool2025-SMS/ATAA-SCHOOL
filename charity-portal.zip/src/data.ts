import { CarouselSlide, FeatureBox, NewsItem, CharityProject, ProgramItem, FAQItem, UserAccount } from './types';

export const CAROUSEL_SLIDES: CarouselSlide[] = [
  {
    id: 1,
    image: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?q=80&w=1200&auto=format&fit=crop",
    title: "Learning and Growing Together",
    subtitle: "Creating a positive, nurturing environment where every child feels valued, encouraged, and excited to explore the world.",
    dotsColor: ["bg-[#3b82f6]", "bg-gray-300", "bg-gray-300", "bg-gray-300"]
  },
  {
    id: 2,
    image: "https://images.unsplash.com/photo-1516627145497-ae6968895b74?q=80&w=1200&auto=format&fit=crop",
    title: "Creativity & Art Workshops",
    subtitle: "Empowering children to express their imaginations through vibrant colors, hands-on crafting, and collective music-making.",
    dotsColor: ["bg-gray-300", "bg-[#f97316]", "bg-gray-300", "bg-gray-300"]
  },
  {
    id: 3,
    image: "https://images.unsplash.com/photo-1509062522246-3755977927d7?q=80&w=1200&auto=format&fit=crop",
    title: "Healthy Nutrition & Warm Meals",
    subtitle: "Fueling bright young minds and bodies with warm, balanced, and locally sourced organic meals served every school day.",
    dotsColor: ["bg-gray-300", "bg-gray-300", "bg-[#eab308]", "bg-gray-300"]
  }
];

export const FEATURE_BOXES: FeatureBox[] = [
  {
    id: "mission",
    title: "Mission & Services",
    description: "Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea.",
    bgColor: "bg-[#22c55e]", // matches bright green
    btnColor: "bg-[#e11d48]", // matches rose-red
    icon: "handshake"
  },
  {
    id: "donations",
    title: "Make Donations",
    description: "Ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea.",
    bgColor: "bg-[#f97316]", // matches bright orange
    btnColor: "bg-[#7c3aed]", // matches purple
    icon: "heart"
  },
  {
    id: "programs",
    title: "Our Programs",
    description: "Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea.",
    bgColor: "bg-[#ef4444]", // matches coral-red
    btnColor: "bg-[#eab308]", // matches golden amber
    icon: "lightbulb"
  }
];

export const NEWS_ITEMS: NewsItem[] = [
  {
    id: 1,
    date: "12 Dec, 2012",
    title: "Lorem ipsum dolor sit amet conse ctetur",
    excerpt: "Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
  },
  {
    id: 2,
    date: "12 Dec, 2012",
    title: "Dolor sit amet conse ctetur ad",
    excerpt: "Dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.",
    content: "Dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
  },
  {
    id: 3,
    date: "24 Nov, 2012",
    title: "Consectetur adipisicing elit sed do",
    excerpt: "Consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    content: "Consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur."
  }
];

export const CHARITY_PROJECTS: CharityProject[] = [
  {
    id: "education",
    title: "Primary School Education Fund",
    category: "Education",
    description: "Providing complete sets of textbooks, learning toolkits, modern classroom equipment, and support guides for schools serving underprivileged children.",
    image: "https://images.unsplash.com/photo-1577896851231-70ef18881754?q=80&w=600&auto=format&fit=crop",
    goal: 20000,
    raised: 16400,
    donorsCount: 342
  },
  {
    id: "healthcare",
    title: "Children's Medical Aid Program",
    category: "Healthcare",
    description: "Financing health screenings, vaccination programs, eye exams, and clean dental hygiene workshops for kids in community pre-schools.",
    image: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?q=80&w=600&auto=format&fit=crop",
    goal: 15000,
    raised: 9200,
    donorsCount: 198
  },
  {
    id: "nutrition",
    title: "Healthy Meals and Snack Support",
    category: "Nutrition",
    description: "Providing delicious, wholesome, organic, daily warm lunches and healthy afternoon snacks to fuel growth and classroom focus.",
    image: "https://images.unsplash.com/photo-1593113598332-cd288d649433?q=80&w=600&auto=format&fit=crop",
    goal: 10000,
    raised: 8500,
    donorsCount: 220
  },
  {
    id: "water",
    title: "Playground Water Wells Initiative",
    category: "Environment",
    description: "Installing clean, reliable, easy-access drinking water fountains and high-quality filtration systems directly in play areas and classrooms.",
    image: "https://images.unsplash.com/photo-1542810634-71277d95dcbb?q=80&w=600&auto=format&fit=crop",
    goal: 8000,
    raised: 4100,
    donorsCount: 89
  }
];

export const PROGRAMS: ProgramItem[] = [
  {
    id: "prep",
    title: "Pre-School Care & Classroom Prep",
    ageGroup: "Ages 2-4",
    duration: "Daily, 8:00 AM - 1:00 PM",
    description: "Ensuring an effortless transition to formal education. Focused on motor skill development, emotional cooperation, sensory exploration, and introductory phonics/math.",
    image: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?q=80&w=600&auto=format&fit=crop",
    schedule: "Monday to Friday"
  },
  {
    id: "workshops",
    title: "Creative Art & Music Workshops",
    ageGroup: "Ages 4-9",
    duration: "Every Tue & Thu, 3:00 PM - 5:30 PM",
    description: "Unlocking children's innate creative channels. Students paint on canvas, model clay figurines, and explore musical rhythm through lightweight hand-drums and xylophones.",
    image: "https://images.unsplash.com/photo-1516627145497-ae6968895b74?q=80&w=600&auto=format&fit=crop",
    schedule: "Tuesdays & Thursdays"
  },
  {
    id: "reading",
    title: "After-School Book Club & Reading Circle",
    ageGroup: "Ages 5-10",
    duration: "Every Wed, 2:30 PM - 4:30 PM",
    description: "Cultivating a deep, lifelong passion for books. Children read together in small circles, practice aloud, act out short plays, and take home books from our extensive library.",
    image: "https://images.unsplash.com/photo-1509062522246-3755977927d7?q=80&w=600&auto=format&fit=crop",
    schedule: "Wednesdays"
  },
  {
    id: "nutrition-prog",
    title: "Growing Garden & Healthy Eating",
    ageGroup: "Ages 6-12",
    duration: "Saturdays, 10:00 AM - 12:30 PM",
    description: "Teaching kids where real food comes from. They plant seeds, harvest fresh organic vegetables, and assemble simple, nutritious fruit salads and wholesome sandwiches.",
    image: "https://images.unsplash.com/photo-1593113598332-cd288d649433?q=80&w=600&auto=format&fit=crop",
    schedule: "Saturdays"
  }
];

export const FAQS: FAQItem[] = [
  {
    id: 1,
    category: "donations",
    question: "Where do my donation funds go?",
    answer: "Every single cent of your donation goes directly towards purchasing educational books, providing warm balanced meals, and funding vital healthcare services for children in our care. We pride ourselves on operating with 100% financial transparency."
  },
  {
    id: 2,
    category: "donations",
    question: "Is my donation tax-deductible?",
    answer: "Yes, absolutely! We are a fully registered 501(c)(3) charitable non-profit organization. When you donate, you will immediately receive a tax-exempt donation receipt via email for your tax return declarations."
  },
  {
    id: 3,
    category: "volunteering",
    question: "How can I apply to become a classroom volunteer?",
    answer: "We are always thrilled to welcome passionate helpers! Simply navigate to our Contacts page and fill out the inquiry form, select 'Volunteer Opportunities', and our community coordinator will reach out to schedule a safety check and orientation."
  },
  {
    id: 4,
    category: "programs",
    question: "What are the eligibility requirements for the free programs?",
    answer: "Our pre-school preparations and after-school clubs are open to children residing in the surrounding Glasgow municipal districts. Priority is given to low-income households and families who need extra support."
  },
  {
    id: 5,
    category: "general",
    question: "Can I schedule a tour of your educational facility?",
    answer: "Certainly! We welcome visitors, sponsors, and curious parents. Tours are conducted every Friday morning by appointment. Please send us a quick message through our Contacts tab to coordinate a time slot."
  }
];

export const INITIAL_USERS: UserAccount[] = [
  {
    id: "user-1",
    username: "admin",
    fullName: "Chief Administrator",
    email: "admin@charitynet.org",
    role: "Administrator",
    status: "Active",
    password: "admin"
  },
  {
    id: "user-2",
    username: "sarah",
    fullName: "Sarah Jenkins",
    email: "sarah@charitynet.org",
    role: "Coordinator",
    status: "Active",
    password: "sarah"
  },
  {
    id: "user-3",
    username: "david",
    fullName: "David Miller",
    email: "david@charitynet.org",
    role: "Coordinator",
    status: "Active",
    password: "david"
  },
  {
    id: "user-4",
    username: "volunteer_jane",
    fullName: "Jane Doe",
    email: "jane@volunteer.org",
    role: "Volunteer",
    status: "Active",
    password: "jane"
  }
];

